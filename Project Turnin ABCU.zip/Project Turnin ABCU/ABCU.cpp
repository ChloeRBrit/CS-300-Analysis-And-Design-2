#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <algorithm> // For std::sort

using namespace std;

// Define Course struct
struct Course {
    string courseNumber;
    string courseName;
    vector<string> prerequisites;
};

// Function prototypes
vector<Course> readCourseData(const string& filename);
vector<string> tokenize(const string& s, const string& del = ",");
void printCourseList(const vector<Course>& courses);
void printCourseInfo(const vector<Course>& courses, const string& courseNumber);

// Function to read course data from file
vector<Course> readCourseData(const string& filename) {
    vector<Course> courses;
    ifstream fin(filename);
    if (!fin.is_open()) {
        cerr << "Error: Unable to open file " << filename << endl;
        return courses;
    }

    string line;
    while (getline(fin, line)) {
        if (line == "-1") // End of file marker
            break;
        
        vector<string> tokens = tokenize(line);
        if (tokens.size() < 2) {
            cerr << "Error: Invalid data format in file." << endl;
            continue;
        }

        Course course;
        course.courseNumber = tokens[0];
        course.courseName = tokens[1];
        for (size_t i = 2; i < tokens.size(); ++i) {
            course.prerequisites.push_back(tokens[i]);
        }
        courses.push_back(course);
    }

    fin.close();
    return courses;
}

// Function to tokenize a string
vector<string> tokenize(const string& s, const string& del) {
    vector<string> tokens;
    size_t start = 0, end = 0;
    while ((end = s.find(del, start)) != string::npos) {
        tokens.push_back(s.substr(start, end - start));
        start = end + del.length();
    }
    tokens.push_back(s.substr(start));
    return tokens;
}

// Function to print course list sorted alphanumerically
void printCourseList(const vector<Course>& courses) {
    vector<Course> sortedCourses = courses; // Make a copy for sorting
    sort(sortedCourses.begin(), sortedCourses.end(), [](const Course& a, const Course& b) {
        return a.courseNumber < b.courseNumber;
    });

    cout << "\nCourse List (Alphanumeric Order):\n";
    for (const auto& course : sortedCourses) {
        cout << "Course Number: " << course.courseNumber << endl;
        cout << "Course Name: " << course.courseName << endl;
        cout << "Prerequisites: ";
        for (const auto& prereq : course.prerequisites) {
            cout << prereq << " ";
        }
        cout << endl << endl;
    }
}

// Function to print individual course information
void printCourseInfo(const vector<Course>& courses, const string& courseNumber) {
    string courseNumberLower = courseNumber;
    transform(courseNumberLower.begin(), courseNumberLower.end(), courseNumberLower.begin(), ::tolower);

    bool found = false;
    for (const auto& course : courses) {
        string courseNumberDB = course.courseNumber;
        transform(courseNumberDB.begin(), courseNumberDB.end(), courseNumberDB.begin(), ::tolower);

        if (courseNumberDB == courseNumberLower) {
            cout << "Course Number: " << course.courseNumber << endl;
            cout << "Course Name: " << course.courseName << endl;
            cout << "Prerequisites: ";
            for (const auto& prereq : course.prerequisites) {
                cout << prereq << " ";
            }
            cout << endl << endl;
            found = true;
            break;
        }
    }
    if (!found) {
        cout << "Course with given course number not found." << endl;
    }
}

int main() {
    vector<Course> courses;
    bool dataLoaded = false;

    int choice;
    do {
        cout << "\nWelcome to the course planner.\n";
        cout << "1. Load Data Structure.\n";
        cout << "2. Print Course List.\n";
        cout << "3. Print Course.\n";
        cout << "4. Exit.\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1: {
                string filename;
                cout << "Enter the filename ABCU.txt containing the course data: ";
                cin >> filename;
                courses = readCourseData(filename);
                if (!courses.empty()) {
                    dataLoaded = true;
                    cout << "Course data loaded successfully.\n";
                }
                break;
            }
            case 2:
                if (dataLoaded) {
                    printCourseList(courses);
                } else {
                    cout << "Please load the data structure first.\n";
                }
                break;
            case 3:
                if (dataLoaded) {
                    string courseNumber;
                    cout << "Enter course number: ";
                    cin >> courseNumber;
                    printCourseInfo(courses, courseNumber);
                } else {
                    cout << "Please load the data structure first.\n";
                }
                break;
            case 4:
                cout << "Exiting program.\n";
                break;
            default:
                cout << "Invalid choice. Please try again.\n";
        }
    } while (choice != 4);

    return 0;
}